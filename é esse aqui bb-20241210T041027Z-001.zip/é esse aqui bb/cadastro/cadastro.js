let usuarios = JSON.parse(localStorage.getItem('usuarios')) || [];

// Função para cadastrar usuário
function cadastrarUsuario(user, email, senha) {
    if (!user || !email || !senha) {
        throw new Error('Todos os campos são obrigatórios');
    }
    const usuario = {
        user,
        email,
        senha
    };
    usuarios.push(usuario);
    localStorage.setItem('usuarios', JSON.stringify(usuarios));
    return usuario;
}

// Event listener para cadastro
document.getElementById('cadastro-btn').addEventListener('click', (e) => {
    e.preventDefault();
    const user = document.getElementById('user').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    try {
        const usuario = cadastrarUsuario(user, email, senha);
    document.getElementById('mensagem').innerHTML = "Usuário cadastrado com sucesso!";

        // Limpar os campos de formulário
        document.getElementById('user').value = '';
        document.getElementById('email').value = '';
        document.getElementById('senha').value = '';

        // Redirecionar para a página inicial após 2 segundos
        setTimeout(() => {
            window.location.href = '/'; // caminho da sua página inicial
        }, 2000);
    } catch (error) {
        document.getElementById('mensagem').innerHTML = "Erro ao cadastrar usuário: ${error.message}";
    }
});