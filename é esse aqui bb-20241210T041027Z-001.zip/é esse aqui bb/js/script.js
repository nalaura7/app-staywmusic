function verifier() {
  const userLogado = JSON.parse(localStorage.getItem('usuarios'));
  return userLogado != null;
}

const Inputpesquisa = document.getElementById('pesquisa');
const list = document.getElementById('list');

Inputpesquisa.addEventListener('input', (e) => {
  const procura = e.target.value.toLowerCase();
  const listItems = list.children;

  for (let i = 0; i < listItems.length; i++) {
    const listItem = listItems[i];
    const text = listItem.textContent.toLowerCase();

    // Verifica se o texto do item contém a string de pesquisa
    if (text.includes(procura) && procura !== '') {
      listItem.style.display = 'block'; // Exibe o item se corresponder
    } else {
      listItem.style.display = 'none'; // Oculta o item se não corresponder
    }
  }
});

// Função para atualizar os botões "Avaliar" de todos os filmes
function atualizarBotoesAvaliar() {
  const botoesAvaliar = document.querySelectorAll('.playnow_bt');
  
  botoesAvaliar.forEach(botao => {
    const linkAvaliar = botao.closest('.iamge_movies').querySelector('a');
    
    if (verifier()) {
      linkAvaliar.style.pointerEvents = "auto"; 
      botao.style.opacity = "1";  
    } else {
      linkAvaliar.style.pointerEvents = "none";
      botao.style.opacity = "0.5"; 
    }
  });
}

document.addEventListener("DOMContentLoaded", atualizarBotoesAvaliar);