document.getElementById('share').addEventListener('click', function() {
    const profileURL = window.location.href; // URL do perfil
    const shareText = `Confira meu perfil: ${profileURL}`;
    
    if (navigator.share) {
        navigator.share({
            title: 'Perfil do Usuário',
            text: shareText,
            url: profileURL,
        })
        .then(() => console.log('Compartilhado com sucesso!'))
        .catch((error) => console.error('Erro ao compartilhar:', error));
    } else {
        // Fallback para navegadores que não suportam o Web Share API
        alert('Compartilhe este link: ' + profileURL);
    }
});