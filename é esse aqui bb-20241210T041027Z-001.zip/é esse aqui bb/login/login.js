// Função para fazer login
function fazerLogin(email, senha) {
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    const usuario = usuarios.find(
        (usuario) => usuario.email === email && usuario.senha === senha
    );
    return usuario;
}

// Event listener para login
document.getElementById("login-btn").addEventListener("click", (e) => {
    e.preventDefault();
    const email = document.getElementById("email-login").value;
    const senha = document.getElementById("senha-login").value;
    const usuario = fazerLogin(email, senha);
    if (usuario) {
        document.getElementById(
            "mensagem"
        ).innerHTML = "Login efetuado com sucesso!";
        setTimeout(() => {
            window.location.href = '/';
        }, 2000);

    } else {
        document.getElementById("mensagem").innerHTML = "Email ou senha inválidos.";
    }
});