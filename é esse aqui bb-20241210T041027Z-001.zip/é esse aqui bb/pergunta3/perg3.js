
function verificar(email, senha) {
    // Recupera os usuários armazenados no localStorage
    const usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
    
    // Procura o usuário que tem o email e senha fornecidos
    const usuario = usuarios.find(
        (usuario) => usuario.email === email && usuario.senha === senha
    );

    // Retorna o usuário se encontrado, caso contrário retorna null
    return usuario;
}

// Função para permitir a avaliação, após verificar o cadastro
function permitirAvaliar() {
    const email = document.getElementById("email-login").value;
    const senha = document.getElementById("senha-login").value;
    
    // Verifica se o usuário está cadastrado
    const usuario = verificar(email, senha);
    
    if (usuario) {
        // Se o usuário for encontrado, exibe uma mensagem de sucesso
        document.getElementById("mensagem").innerHTML = "Cadastro confirmado. Você pode avaliar agora!";
        
        // Redireciona para a página de avaliação após 2 segundos
        setTimeout(() => {
            window.location.href = "../avaliar/avaliar_birds_of_a_feather.html"; // Aqui você define a página para onde o usuário será redirecionado
        }, 2000);

    } else {
        // Se não encontrado, exibe uma mensagem de erro
        document.getElementById("mensagem").innerHTML = "Você precisa estar cadastrado para avaliar. Faça o cadastro primeiro.";
        
    }
}

// Event listener para o botão de login (ou confirmação de cadastro)
document.getElementById("login-btn").addEventListener("click", (e) => {
    e.preventDefault();
    
    // Chama a função que verifica se o usuário está cadastrado
    permitirAvaliar();
});
